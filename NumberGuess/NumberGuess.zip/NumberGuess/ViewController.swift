//
//  ViewController.swift
//  NumberGuess
//
//  Created by Fuchshuber Felix on 01.10.21.
//

import UIKit

class ViewController: UIViewController {

    var model = Model()
    
    @IBOutlet weak var guessButton: UIButton!
    @IBOutlet weak var lable: UILabel!
    @IBOutlet weak var textField: UITextField!
    @IBAction func button(_ sender: Any){
        let guessNumber = Int(textField.text!)!
        
        
        if guessNumber < model.numberToGuess {
            lable.text = "Too low"
        }
        
        if guessNumber == model.numberToGuess {
            lable.text = "You guessed it!"
        }
        
        if guessNumber > model.numberToGuess {
            lable.text = "Too high"
        }
        
        model.countOfTries += 1
        
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        model.numberToGuess = Int.random(in:
            0..<100)
        print("zu erratende:\(model.numberToGuess)")
        // Do any additional setup after loading the view.
    }
}
