class Model {
    var numberToGuess = 0
    var countOfTries = 0
}
